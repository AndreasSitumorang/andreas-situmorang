import React from "react";
// import Header from "./Component/Layout/Header";
import Nopage from "./Component/Pages/NoPage";
import Blog from "./Component/Pages/BlogPage";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Component/Pages/HomePage";
import ListingItem from "./Component/Items/ListItem/ListingItem";

function App(props) {
  const test = {ListingItem};
  console.log('test : ',test);
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route index element={<Home />} />
          <Route path="blog" element={<Blog />} />
          <Route path= ":name"  element={<Nopage />} />
        </Routes>
      </BrowserRouter>
      {/* <header>
      <Header />
      </header> */}
    </div>
  );
}


export default App;
