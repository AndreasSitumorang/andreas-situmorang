// import { event } from "jquery";
// import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";

const Navigation = (props) => {

  const newDefault = {
    id: "m6" + Math.floor(100000 + Math.random() * 900000).toString(),
    name: "New World",
    description: "Fresh and green...",
    price: 18.99,
  };


  function handleSubmit(e) {
    e.preventDefault(); 
    console.log("is cliked");
    // props.onSubmitForm(true);


    props.onSubmitForm(newDefault);
  }

  return (
    <Navbar expand="lg" variant="light" bg="light" sticky="top" className="mb-4" >
      <Container fluid>
        <Navbar.Brand href="/">Home Page</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: "150px" }}
            navbarScroll
          >
            <Nav.Link href="/blog">Home</Nav.Link>
            <Nav.Link href="/nopage">Link</Nav.Link>
          </Nav>
          <Form className="d-flex" onSubmit={handleSubmit}>
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button type="submit" variant="outline-success">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navigation;
