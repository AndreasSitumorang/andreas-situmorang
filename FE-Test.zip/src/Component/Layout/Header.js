import React from "react";
import Styles from "./Header.module.css";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
// import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";

const Header = () => {
  return (
    <Nav>
      <header className={Styles.header}>
          <Row>
            <Col xs={6} style={{ width: "250px" }}>
              <h3 data-cy="header-title">TO DO LIST APP</h3>
            </Col>
          </Row>
      </header>
    </Nav>
  );
};

export default Header;
