import React from "react";
import Style from "./Card.module.css";

const Card = (props) => {
  return <div className={Style.card} sticky="top">{props.children}</div>;
};

export default Card;
