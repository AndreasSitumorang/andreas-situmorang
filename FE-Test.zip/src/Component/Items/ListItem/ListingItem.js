import React from "react";
import Card from "react-bootstrap/Card";

import { Link } from "react-router-dom";

const ListingItem = (props) => {
  return (
    <Link
      to={props.name}
      className="normal-text"
      style={{ textDecoration: "none", color: "black" }}
      state={{ from: "occupation" }}
    >
      <Card
        border="light"
        style={{
          width: "250px",
          height: "260px",
          boxShadow: "0 4px 8px rgb(0 0 0 / 15%)",
          margin: "10px 10px 10px 10px",
          cursor: "pointer",
        }}
      >
        <Card.Body style={{ width: "230px", height: "234px" }}>
          <h4>{props.name}</h4>
        </Card.Body>
      </Card>
    </Link>
  );
};

// export {//itemNames};
export default ListingItem;
