import React from "react";
import ListingItem from "./ListItem/ListingItem";

const ItemAvaliable = (props) => {
  
  console.log(props.allItemsBag);

  const Itemlisting = props.allItemsBag.map((items) => (
    <ListingItem
      key={items.id + items.name}
      id={items.id}
      name={items.name}
      description={items.description}
      price={items.price}
    />
  ));
  return <>{Itemlisting}</>;
};

export default ItemAvaliable;
