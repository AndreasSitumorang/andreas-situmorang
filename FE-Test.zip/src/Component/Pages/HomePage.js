import React, { useState } from "react";
import ItemAvaliable from "../Items/ItemAvaliable";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Header from "../Layout/Header";
import Navigation from "../Layout/Navigation";

const Home = () => {

  // const [onClikedItem, setOnclikedItem] = useState(false);

  let DUMMY_MEALS = [
    {
      id: "m1",
      name: "Sushi",
      description: "Finest fish and veggies",
      price: 22.99,
    },
    {
      id: "m2",
      name: "Schnitzel",
      description: "A german specialty!",
      price: 16.5,
    },
    {
      id: "m3",
      name: "Barbecue Burger",
      description: "American, raw, meaty",
      price: 12.99,
    },
    {
      id: "m4",
      name: "Green Bowl",
      description: "Healthy...and green...",
      price: 18.99,
    },
    {
      id: "m5",
      name: "Green Wood",
      description: "Fresh and green...",
      price: 18.99,
    },
  ];

  
  const [mealsItems, setMealsItems]= useState(DUMMY_MEALS);

  // const isclikeds = formHasSubmited;
  const addMealsItemHanlder = (newDefault) =>{
    console.log(newDefault);
    setMealsItems((preventDefault) => {
      return [newDefault, ...preventDefault];
    } );
  };

  // const clikedButton = (formHasSubmited) => {
  //   // setOnclikedItem( () => {return formHasSubmited })
  //   console.log('formHasSubmited :',formHasSubmited);
  //   let ayam = formHasSubmited;
  // }
  
  // console.log('onClikedItem :',onClikedItem);

  return (
    <>
      <Header />
      <Container>
        <div>
          <Navigation onSubmitForm={addMealsItemHanlder} />
          <Row xs={5} md={4} className="g-4">
            <ItemAvaliable
              addingNewItem = {addMealsItemHanlder}
              allItemsBag = {mealsItems}
            />
          </Row>
        </div>
      </Container>
    </>
  );
};

export default Home;
